# My Personal Project

## Financial log

This application will be a finace tracker each user can use easily financial expensies and goals they they can make. Each user will have an id/useranme and password. Each time a user loggs their expenses or income they can select a catetory or make a new category for their expense. For example, if user1 bought lunch outside for $14.50 they can log the information Date - $14.50 - restaurant name/food - category: food. Later on, the user can check where they are spending the most amount of money within a time frame by using a pie chart. This project intrested me because I personally log my expenses in order to save money and to learn to control buying food and drinks outside; however, there has been constant problems doing this on a spread sheet and overall not visually satisfying to view. This application can be useful who anyone who has a financial goal or whoever wishes to organize their expenses easily.
