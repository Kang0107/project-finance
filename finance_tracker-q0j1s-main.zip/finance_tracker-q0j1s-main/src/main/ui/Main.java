package ui;

// import user.AuthenticateUser;
import user.BudgetApp;

public class Main {
    
    public static void main(String[] args) {
        // new AuthenticateUser();
        new BudgetApp();
    }
        
}