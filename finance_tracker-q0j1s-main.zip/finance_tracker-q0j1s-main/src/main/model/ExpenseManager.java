package model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ExpenseManager {
    private List<Expense> listOfExpense; // Store list of expenses

    public ExpenseManager() {
        listOfExpense = new ArrayList<>();
    }

    public void addExpense(double amount, String category, String date) {
        Expense expense = new Expense(amount, category, date);
        listOfExpense.add(expense);
        System.out.println("Expense added successfully.");
    }

    public void removeExpense(double amount, String category) {
        Iterator<Expense> iterator = listOfExpense.iterator();
        while (iterator.hasNext()) {
            Expense expense = iterator.next();
            if (expense.getAmount() == amount && expense.getCategory().equalsIgnoreCase(category)) {
                iterator.remove();
                System.out.println("Removed expense successfully.");
                return;
            }
        }
        System.out.println("Expense not found.");
    }

    public void printExpenses() {
        String ans = "";

        if (listOfExpense.isEmpty()) {
            System.out.println("No expenses recorded.");
        }

        Integer count = 1;
        for (Expense expense : listOfExpense) {
            String oneExpense = expense.toString();
            ans += "Expense #" + count + ": " + oneExpense;
            count++;
        }

        System.out.println("\n=== Expenses ===");
        System.out.println(ans);
    }

    public double getTotalExpenses() {
        double total = 0;
        for (Expense expense : listOfExpense) {
            total += expense.getAmount();
        }
        return total;
    }

    public List<Expense> getExpenses() {
        return listOfExpense;
    }
}
