package model;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestSample {

    @BeforeEach
    void runBefore() {

    }

    @Test
    void sampleTest() {
        assertTrue(true);
    }
}
